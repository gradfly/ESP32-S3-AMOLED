#include "ui_main.h"
#include "lcd_bsp.h"
#include "lcd_config.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "UI";

static lv_obj_t *s_screen_main = NULL;
static lv_obj_t *s_screen_list = NULL;
static lv_obj_t *s_screen_data = NULL;

static lv_obj_t *s_status_label = NULL;
static lv_obj_t *s_scan_list = NULL;
static lv_obj_t *s_connect_btn = NULL;
static lv_obj_t *s_disconnect_btn = NULL;
static lv_obj_t *s_scan_btn = NULL;

/* 数据屏：11 通道数值网格 + 原始帧 + 连接状态 */
static lv_obj_t *s_data_status_label = NULL;   /* 显示已连接设备名 */
static lv_obj_t *s_raw_label = NULL;           /* 最新一帧原始字符串 */
static lv_obj_t *s_value_grid = NULL;          /* 11 通道网格容器 */
typedef struct {
    lv_obj_t *title;
    lv_obj_t *value;
} value_cell_t;
static value_cell_t s_cells[BLE_DATA_VALUE_COUNT];

static uint16_t s_selected_device = 0;
static ble_device_info_t s_device_list[BLE_SCAN_RESULT_MAX];
static uint16_t s_device_count = 0;
static char s_connected_name[32] = "";   /* 当前已连接设备名，用于数据屏显示 */

static lv_style_t s_btn_style;
static lv_style_t s_label_style;
static lv_style_t s_title_style;
static lv_style_t s_list_item_selected_style;  /* 设备列表项选中样式：蓝底白字 */

static void event_scan_btn_cb(lv_event_t *e);
static void event_connect_btn_cb(lv_event_t *e);
static void event_disconnect_btn_cb(lv_event_t *e);
static void event_back_btn_cb(lv_event_t *e);
static void event_list_item_cb(lv_event_t *e);
static void event_clear_data_cb(lv_event_t *e);

static void create_main_screen(void);
static void create_list_screen(void);
static void create_data_screen(void);

void ui_init(void)
{
    lv_disp_t *disp = get_display();
    if (!disp) {
        ESP_LOGE(TAG, "Display not initialized");
        return;
    }

    lv_style_init(&s_btn_style);
    lv_style_init(&s_label_style);
    lv_style_init(&s_title_style);
    lv_style_init(&s_list_item_selected_style);

    lv_style_set_bg_color(&s_btn_style, lv_color_hex(0x007AFF));
    lv_style_set_radius(&s_btn_style, 8);
    lv_style_set_text_color(&s_btn_style, lv_color_white());
    lv_style_set_pad_all(&s_btn_style, 12);

    lv_style_set_text_color(&s_label_style, lv_color_hex(0x333333));
    lv_style_set_text_font(&s_label_style, &lv_font_montserrat_14);

    lv_style_set_text_color(&s_title_style, lv_color_hex(0x007AFF));
    lv_style_set_text_font(&s_title_style, &lv_font_montserrat_24);

    /* 设备列表项选中样式：蓝底白字（仅在 LV_STATE_CHECKED 状态下生效） */
    lv_style_set_bg_color(&s_list_item_selected_style, lv_color_hex(0x007AFF));
    lv_style_set_bg_opa(&s_list_item_selected_style, LV_OPA_COVER);
    lv_style_set_text_color(&s_list_item_selected_style, lv_color_white());
    lv_style_set_border_color(&s_list_item_selected_style, lv_color_hex(0x0051D5));
    lv_style_set_border_width(&s_list_item_selected_style, 2);
    lv_style_set_radius(&s_list_item_selected_style, 6);

    create_main_screen();
    create_list_screen();
    create_data_screen();

    lv_scr_load(s_screen_main);
}

static void create_main_screen(void)
{
    s_screen_main = lv_obj_create(NULL);
    lv_obj_set_size(s_screen_main, EXAMPLE_LCD_H_RES, EXAMPLE_LCD_V_RES);
    lv_obj_set_style_bg_color(s_screen_main, lv_color_hex(0xFFFFFF), 0);

    lv_obj_t *title = lv_label_create(s_screen_main);
    lv_label_set_text(title, "BLE Serial");
    lv_obj_add_style(title, &s_title_style, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 30);

    s_scan_btn = lv_btn_create(s_screen_main);
    lv_obj_add_style(s_scan_btn, &s_btn_style, 0);
    lv_obj_set_size(s_scan_btn, 200, 50);
    lv_obj_align(s_scan_btn, LV_ALIGN_CENTER, 0, -40);
    lv_obj_t *scan_label = lv_label_create(s_scan_btn);
    lv_label_set_text(scan_label, "Scan Devices");
    lv_obj_add_event_cb(s_scan_btn, event_scan_btn_cb, LV_EVENT_CLICKED, NULL);

    s_status_label = lv_label_create(s_screen_main);
    lv_label_set_text(s_status_label, "Ready");
    lv_obj_add_style(s_status_label, &s_label_style, 0);
    lv_obj_align(s_status_label, LV_ALIGN_CENTER, 0, 30);
}

static void create_list_screen(void)
{
    s_screen_list = lv_obj_create(NULL);
    lv_obj_set_size(s_screen_list, EXAMPLE_LCD_H_RES, EXAMPLE_LCD_V_RES);
    lv_obj_set_style_bg_color(s_screen_list, lv_color_hex(0xFFFFFF), 0);

    lv_obj_t *title = lv_label_create(s_screen_list);
    lv_label_set_text(title, "Devices");
    lv_obj_add_style(title, &s_title_style, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 20);

    lv_obj_t *back_btn = lv_btn_create(s_screen_list);
    lv_obj_set_size(back_btn, 60, 40);
    lv_obj_align(back_btn, LV_ALIGN_TOP_LEFT, 10, 15);
    lv_obj_t *back_label = lv_label_create(back_btn);
    lv_label_set_text(back_label, "Back");
    lv_obj_add_event_cb(back_btn, event_back_btn_cb, LV_EVENT_CLICKED, NULL);

    s_scan_list = lv_list_create(s_screen_list);
    lv_obj_set_size(s_scan_list, EXAMPLE_LCD_H_RES - 20, 300);
    lv_obj_align(s_scan_list, LV_ALIGN_TOP_MID, 0, 70);

    s_connect_btn = lv_btn_create(s_screen_list);
    lv_obj_add_style(s_connect_btn, &s_btn_style, 0);
    lv_obj_set_size(s_connect_btn, 200, 50);
    lv_obj_align(s_connect_btn, LV_ALIGN_BOTTOM_MID, 0, -20);
    lv_obj_t *connect_label = lv_label_create(s_connect_btn);
    lv_label_set_text(connect_label, "Connect");
    lv_obj_add_event_cb(s_connect_btn, event_connect_btn_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_add_flag(s_connect_btn, LV_OBJ_FLAG_HIDDEN);
}

static void create_data_screen(void)
{
    s_screen_data = lv_obj_create(NULL);
    lv_obj_set_size(s_screen_data, EXAMPLE_LCD_H_RES, EXAMPLE_LCD_V_RES);
    lv_obj_set_style_bg_color(s_screen_data, lv_color_hex(0xFFFFFF), 0);

    lv_obj_t *title = lv_label_create(s_screen_data);
    lv_label_set_text(title, "BLE Data");
    lv_obj_add_style(title, &s_title_style, 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 12);

    lv_obj_t *back_btn = lv_btn_create(s_screen_data);
    lv_obj_set_size(back_btn, 56, 36);
    lv_obj_align(back_btn, LV_ALIGN_TOP_LEFT, 8, 8);
    lv_obj_t *back_label = lv_label_create(back_btn);
    lv_label_set_text(back_label, "Back");
    lv_obj_add_event_cb(back_btn, event_back_btn_cb, LV_EVENT_CLICKED, NULL);

    /* 连接状态行：显示已连接的设备名 */
    s_data_status_label = lv_label_create(s_screen_data);
    lv_label_set_text(s_data_status_label, "Connecting...");
    lv_obj_add_style(s_data_status_label, &s_label_style, 0);
    lv_obj_set_style_text_color(s_data_status_label, lv_color_hex(0x34C759), 0);
    lv_obj_align(s_data_status_label, LV_ALIGN_TOP_MID, 0, 52);

    /* 11 通道数值网格：2 列手动定位，每格显示 "ChN" + 4 位数值。
     * 不依赖 LV_USE_FLEX，兼容性更好。 */
    s_value_grid = lv_obj_create(s_screen_data);
    lv_obj_set_size(s_value_grid, EXAMPLE_LCD_H_RES - 12, 282);
    lv_obj_align(s_value_grid, LV_ALIGN_TOP_MID, 0, 76);
    lv_obj_set_style_pad_all(s_value_grid, 4, 0);
    lv_obj_set_style_border_width(s_value_grid, 0, 0);
    lv_obj_set_style_bg_opa(s_value_grid, LV_OPA_TRANSP, 0);
    lv_obj_set_scrollbar_mode(s_value_grid, LV_SCROLLBAR_MODE_OFF);

    for (uint8_t i = 0; i < BLE_DATA_VALUE_COUNT; i++) {
        uint8_t col = i % 2;       /* 0=左列, 1=右列 */
        uint8_t row = i / 2;       /* 0..5 */
        lv_coord_t x = col ? 136 : 4;
        lv_coord_t y = 4 + row * 46;

        lv_obj_t *cell = lv_obj_create(s_value_grid);
        lv_obj_set_pos(cell, x, y);
        lv_obj_set_size(cell, 124, 42);
        lv_obj_set_style_bg_color(cell, lv_color_hex(0xF2F2F7), 0);
        lv_obj_set_style_radius(cell, 6, 0);
        lv_obj_set_style_pad_all(cell, 3, 0);
        lv_obj_set_style_border_width(cell, 0, 0);
        lv_obj_clear_flag(cell, LV_OBJ_FLAG_SCROLLABLE);

        lv_obj_t *t = lv_label_create(cell);
        lv_label_set_text_fmt(t, "Ch%d", i + 1);
        lv_obj_set_style_text_font(t, &lv_font_montserrat_12, 0);
        lv_obj_set_style_text_color(t, lv_color_hex(0x8E8E93), 0);
        lv_obj_align(t, LV_ALIGN_TOP_LEFT, 4, 2);

        lv_obj_t *v = lv_label_create(cell);
        lv_label_set_text(v, "----");
        lv_obj_set_style_text_font(v, &lv_font_montserrat_20, 0);
        lv_obj_set_style_text_color(v, lv_color_hex(0x007AFF), 0);
        lv_obj_align(v, LV_ALIGN_BOTTOM_RIGHT, -4, -2);

        s_cells[i].title = t;
        s_cells[i].value = v;
    }

    /* 最新一帧原始数据（调试用，单行省略） */
    s_raw_label = lv_label_create(s_screen_data);
    lv_label_set_text(s_raw_label, "Raw: --");
    lv_obj_add_style(s_raw_label, &s_label_style, 0);
    lv_obj_set_style_text_color(s_raw_label, lv_color_hex(0x8E8E93), 0);
    lv_obj_set_width(s_raw_label, EXAMPLE_LCD_H_RES - 16);
    lv_label_set_long_mode(s_raw_label, LV_LABEL_LONG_DOT);
    lv_obj_align(s_raw_label, LV_ALIGN_TOP_MID, 0, 368);

    s_disconnect_btn = lv_btn_create(s_screen_data);
    lv_obj_add_style(s_disconnect_btn, &s_btn_style, 0);
    lv_obj_set_size(s_disconnect_btn, 130, 42);
    lv_obj_align(s_disconnect_btn, LV_ALIGN_BOTTOM_LEFT, 10, -10);
    lv_obj_t *disconnect_label = lv_label_create(s_disconnect_btn);
    lv_label_set_text(disconnect_label, "Disconnect");
    lv_obj_add_event_cb(s_disconnect_btn, event_disconnect_btn_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *clear_btn = lv_btn_create(s_screen_data);
    lv_obj_add_style(clear_btn, &s_btn_style, 0);
    lv_obj_set_style_bg_color(clear_btn, lv_color_hex(0x8E8E93), 0);
    lv_obj_set_size(clear_btn, 90, 42);
    lv_obj_align(clear_btn, LV_ALIGN_BOTTOM_RIGHT, -10, -10);
    lv_obj_t *clear_label = lv_label_create(clear_btn);
    lv_label_set_text(clear_label, "Clear");
    lv_obj_add_event_cb(clear_btn, event_clear_data_cb, LV_EVENT_CLICKED, NULL);
}

void ui_switch_screen(ui_screen_t screen)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) return;

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) return;

    switch (screen) {
    case UI_SCREEN_MAIN:
        lv_scr_load(s_screen_main);
        break;
    case UI_SCREEN_LIST:
        lv_scr_load(s_screen_list);
        break;
    case UI_SCREEN_DATA:
        lv_scr_load(s_screen_data);
        break;
    }

    xSemaphoreGiveRecursive(mux);
}

void ui_update_state(ble_state_t state, const char *message)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) return;

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) return;

    if (s_status_label) {
        lv_label_set_text(s_status_label, message);
    }

    switch (state) {
    case BLE_STATE_SCANNING:
        if (s_scan_btn) {
            lv_obj_t *lbl = lv_obj_get_child(s_scan_btn, 0);
            if (lbl) lv_label_set_text(lbl, "Scanning...");
            lv_obj_add_state(s_scan_btn, LV_STATE_DISABLED);
        }
        break;
    case BLE_STATE_IDLE:
        if (s_scan_btn) {
            lv_obj_t *lbl = lv_obj_get_child(s_scan_btn, 0);
            if (lbl) lv_label_set_text(lbl, "Scan Devices");
            lv_obj_clear_state(s_scan_btn, LV_STATE_DISABLED);
        }
        break;
    case BLE_STATE_CONNECTING:
        if (s_data_status_label) {
            lv_label_set_text(s_data_status_label, "Connecting...");
        }
        break;
    case BLE_STATE_CONNECTED:
        if (s_data_status_label) {
            char buf[48];
            snprintf(buf, sizeof(buf), "Connected: %s",
                     s_connected_name[0] ? s_connected_name : "device");
            lv_label_set_text(s_data_status_label, buf);
        }
        ui_clear_data();
        ui_switch_screen(UI_SCREEN_DATA);
        break;
    case BLE_STATE_DISCONNECTED:
        s_connected_name[0] = '\0';
        if (s_data_status_label) {
            lv_label_set_text(s_data_status_label, "Disconnected");
        }
        ui_switch_screen(UI_SCREEN_MAIN);
        break;
    default:
        break;
    }

    xSemaphoreGiveRecursive(mux);
}

void ui_update_scan_results(void)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) {
        ESP_LOGW(TAG, "LVGL mutex not available, skipping UI update");
        return;
    }

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) {
        ESP_LOGW(TAG, "Failed to take LVGL mutex");
        return;
    }

    if (s_scan_list) {
        lv_obj_clean(s_scan_list);

        ble_manager_get_scan_results(s_device_list, &s_device_count);

        ESP_LOGI(TAG, "Updating scan results: %d devices", s_device_count);

        for (uint16_t i = 0; i < s_device_count; i++) {
            char buf[128];
            if (s_device_list[i].has_custom_id) {
                /* 优先显示自定义 UUID + SN（随机 MAC 场景下的稳定标识） */
                snprintf(buf, sizeof(buf), "%s\nUUID:%08lX SN:%lu  RSSI:%d",
                         s_device_list[i].name,
                         (unsigned long)s_device_list[i].custom_uuid,
                         (unsigned long)s_device_list[i].sn,
                         s_device_list[i].rssi);
            } else {
                /* 无自定义 ID 时回退到 MAC 地址 */
                snprintf(buf, sizeof(buf), "%s\n%02X:%02X:%02X:%02X:%02X:%02X  RSSI: %d",
                         s_device_list[i].name,
                         s_device_list[i].mac[0], s_device_list[i].mac[1], s_device_list[i].mac[2],
                         s_device_list[i].mac[3], s_device_list[i].mac[4], s_device_list[i].mac[5],
                         s_device_list[i].rssi);
            }

            lv_obj_t *btn = lv_list_add_btn(s_scan_list, LV_SYMBOL_WIFI, buf);
            lv_obj_set_user_data(btn, (void *)(intptr_t)i);
            /* 启用可选中标志 + 绑定选中样式（蓝底白字，仅在 LV_STATE_CHECKED 下生效） */
            lv_obj_add_flag(btn, LV_OBJ_FLAG_CHECKABLE);
            lv_obj_add_style(btn, &s_list_item_selected_style, LV_PART_MAIN | LV_STATE_CHECKED);
            lv_obj_add_event_cb(btn, event_list_item_cb, LV_EVENT_CLICKED, NULL);

            ESP_LOGI(TAG, "  Device %d: %s, RSSI=%d", i + 1, s_device_list[i].name, s_device_list[i].rssi);
        }

        if (s_device_count > 0) {
            lv_obj_clear_flag(s_connect_btn, LV_OBJ_FLAG_HIDDEN);
            ESP_LOGI(TAG, "Connect button shown");
        } else {
            lv_obj_add_flag(s_connect_btn, LV_OBJ_FLAG_HIDDEN);
            ESP_LOGW(TAG, "No devices found, connect button hidden");
        }
    } else {
        ESP_LOGW(TAG, "s_scan_list is NULL, cannot update scan results");
    }

    xSemaphoreGiveRecursive(mux);
}

void ui_append_data(const uint8_t *data, uint16_t len)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) return;

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) return;

    /* 仅显示最新一帧原始数据（实时刷新，不累加） */
    if (s_raw_label && len > 0) {
        char buf[128];
        uint16_t copy_len = (len < sizeof(buf) - 8) ? len : sizeof(buf) - 8;
        memcpy(buf, "Raw: ", 5);
        memcpy(buf + 5, data, copy_len);
        buf[5 + copy_len] = '\0';
        lv_label_set_text(s_raw_label, buf);
    }

    xSemaphoreGiveRecursive(mux);
}

void ui_update_data_values(const int16_t *values, uint8_t count)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) return;

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) return;

    /* 用 4 位零填充显示，与源数据 "0920"/"0000" 格式一致 */
    for (uint8_t i = 0; i < count && i < BLE_DATA_VALUE_COUNT; i++) {
        if (s_cells[i].value) {
            lv_label_set_text_fmt(s_cells[i].value, "%04d", values[i]);
        }
    }

    xSemaphoreGiveRecursive(mux);
}

void ui_clear_data(void)
{
    SemaphoreHandle_t mux = get_lvgl_mutex();
    if (!mux) return;

    if (xSemaphoreTakeRecursive(mux, pdMS_TO_TICKS(100)) != pdTRUE) return;

    for (uint8_t i = 0; i < BLE_DATA_VALUE_COUNT; i++) {
        if (s_cells[i].value) {
            lv_label_set_text(s_cells[i].value, "----");
        }
    }
    if (s_raw_label) {
        lv_label_set_text(s_raw_label, "Raw: --");
    }

    xSemaphoreGiveRecursive(mux);
}

static void event_scan_btn_cb(lv_event_t *e)
{
    ui_switch_screen(UI_SCREEN_LIST);
    ble_manager_start_scan();
}

static void event_connect_btn_cb(lv_event_t *e)
{
    if (s_selected_device < s_device_count) {
        /* 保存设备名供数据屏连接成功后显示 */
        strncpy(s_connected_name, s_device_list[s_selected_device].name,
                sizeof(s_connected_name) - 1);
        s_connected_name[sizeof(s_connected_name) - 1] = '\0';
        ble_manager_connect(&s_device_list[s_selected_device]);
    }
}

static void event_disconnect_btn_cb(lv_event_t *e)
{
    ble_manager_disconnect();
}

static void event_back_btn_cb(lv_event_t *e)
{
    ui_switch_screen(UI_SCREEN_MAIN);
}

static void event_list_item_cb(lv_event_t *e)
{
    lv_obj_t *btn = lv_event_get_target(e);
    s_selected_device = (uint16_t)(intptr_t)lv_obj_get_user_data(btn);

    /* 单选逻辑：清除所有列表项的 CHECKED 状态，仅给当前项添加 CHECKED 状态
     * 触发 s_list_item_selected_style（蓝底白字）生效 */
    for (uint16_t i = 0; i < s_device_count; i++) {
        lv_obj_t *child = lv_obj_get_child(s_scan_list, i);
        if (child && child != btn) {
            lv_obj_clear_state(child, LV_STATE_CHECKED);
        }
    }
    lv_obj_add_state(btn, LV_STATE_CHECKED);
}

static void event_clear_data_cb(lv_event_t *e)
{
    ui_clear_data();
}
