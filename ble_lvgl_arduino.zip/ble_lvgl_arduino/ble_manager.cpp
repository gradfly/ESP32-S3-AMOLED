#include "ble_manager.h"
#include <Arduino.h>
#include <NimBLEDevice.h>
#include <WiFi.h>
#include "esp_log.h"
#include "esp_bt.h"
#include "esp_wifi.h"
#include <string.h>

static const char *TAG = "BLE_MANAGER";

static ble_state_t s_state = BLE_STATE_IDLE;
static ble_device_info_t s_scan_results[BLE_SCAN_RESULT_MAX];
static uint16_t s_scan_result_count = 0;
static ble_data_callback_t s_data_cb = NULL;
static ble_state_callback_t s_state_cb = NULL;
static uint32_t s_scan_start_ms = 0;

static NimBLEScan *s_scan = nullptr;
static NimBLEClient *s_client = nullptr;
static NimBLERemoteCharacteristic *s_rx_char = nullptr;
static NimBLERemoteCharacteristic *s_tx_char = nullptr;

static bool s_is_connected = false;
static uint8_t s_remote_mac[6] = {0};
static TaskHandle_t s_connect_task_handle = NULL;
static ble_device_info_t s_connect_device;

typedef struct {
    uint8_t data[BLE_DATA_BUFFER_SIZE];
    uint16_t len;
} ble_data_msg_t;

static QueueHandle_t s_data_queue = NULL;

/* 帧重组缓冲区：BLE notify 单次最多 20 字节（MTU=23 时），
 * 一帧 "1800,1600,...,0000;" 约 53 字节会被拆成多次 notify 到达，
 * 必须按帧尾 ';' 拼接成完整帧后再交给上层解析。
 */
static char s_frame_buf[128];
static uint16_t s_frame_len = 0;

static void update_state(ble_state_t state, const char *message)
{
    s_state = state;
    if (s_state_cb) {
        s_state_cb(state, message);
    }
}

static void notify_callback(NimBLERemoteCharacteristic *pCharacteristic,
                             uint8_t *data, size_t length, bool isNotify)
{
    if (isNotify && s_data_queue && s_data_cb) {
        ble_data_msg_t msg;
        uint16_t copy_len = (length > BLE_DATA_BUFFER_SIZE) ? BLE_DATA_BUFFER_SIZE : length;
        memcpy(msg.data, data, copy_len);
        msg.len = copy_len;
        BaseType_t higher_priority_task_woken = pdFALSE;
        xQueueSendFromISR(s_data_queue, &msg, &higher_priority_task_woken);
    }
}

class MyAdvertisedDeviceCallbacks : public NimBLEScanCallbacks
{
    void onResult(const NimBLEAdvertisedDevice *advertisedDevice) override
    {
        /* 解析广播包中的 Manufacturer Data，提取自定义 UUID + SN
         * 数据格式: [MFR_ID(2)] [UUID(4)] [SN(4)] = 10 字节
         * MFR_ID = BLE_CUSTOM_MFR_ID (0xFF00)
         */
        bool has_custom_id = false;
        uint32_t custom_uuid = 0;
        uint32_t sn = 0;

        if (advertisedDevice->haveManufacturerData()) {
            std::string mfrData = advertisedDevice->getManufacturerData();
            if (mfrData.length() >= 10) {
                uint16_t mfrId = (uint8_t)mfrData[0] | ((uint8_t)mfrData[1] << 8);
                if (mfrId == BLE_CUSTOM_MFR_ID) {
                    has_custom_id = true;
                    memcpy(&custom_uuid, mfrData.data() + 2, 4);
                    memcpy(&sn, mfrData.data() + 6, 4);
                }
            }
        }

        /* 去重：如果设备带自定义 ID，按 UUID+SN 去重；
         * 否则按 MAC 去重（随机 MAC 场景下可能重复，但无更好方案）
         */
        for (uint16_t i = 0; i < s_scan_result_count; i++) {
            ble_device_info_t *existing = &s_scan_results[i];
            bool is_same = false;
            if (has_custom_id && existing->has_custom_id) {
                /* 按 UUID+SN 去重（忽略随机 MAC 变化） */
                is_same = (existing->custom_uuid == custom_uuid &&
                           existing->sn == sn);
            } else {
                /* 按 MAC 去重 */
                is_same = (memcmp(existing->mac, advertisedDevice->getAddress().getVal(), 6) == 0);
            }
            if (is_same) {
                /* 更新 RSSI（取更强的信号） */
                if (advertisedDevice->getRSSI() > existing->rssi) {
                    existing->rssi = advertisedDevice->getRSSI();
                }
                /* 更新 MAC（随机 MAC 可能已变化，保存最新的用于连接） */
                memcpy(existing->mac, advertisedDevice->getAddress().getVal(), 6);
                existing->addr_type = advertisedDevice->getAddressType();
                return;
            }
        }

        /* 新设备，添加到列表 */
        if (s_scan_result_count < BLE_SCAN_RESULT_MAX) {
            ble_device_info_t *dev = &s_scan_results[s_scan_result_count];

            const NimBLEAddress &addr = advertisedDevice->getAddress();
            const uint8_t *mac = addr.getVal();
            memcpy(dev->mac, mac, 6);
            dev->addr_type = advertisedDevice->getAddressType();
            dev->rssi = advertisedDevice->getRSSI();
            dev->has_custom_id = has_custom_id;
            dev->custom_uuid = custom_uuid;
            dev->sn = sn;

            if (advertisedDevice->haveName()) {
                std::string name = advertisedDevice->getName();
                strncpy(dev->name, name.c_str(), sizeof(dev->name) - 1);
                dev->name[sizeof(dev->name) - 1] = '\0';
            } else {
                strcpy(dev->name, "(no name)");
            }

            if (has_custom_id) {
                ESP_LOGI(TAG, "Found device: %s, UUID: %08X, SN: %08X, MAC: %02X:%02X:%02X:%02X:%02X:%02X, RSSI: %d",
                         dev->name, custom_uuid, sn,
                         mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], dev->rssi);
                Serial.printf("[BLE] Found device %d: %s, UUID:%08X SN:%08X, RSSI: %d\n",
                              s_scan_result_count + 1, dev->name, custom_uuid, sn, dev->rssi);
            } else {
                ESP_LOGI(TAG, "Found device: %s, MAC: %02X:%02X:%02X:%02X:%02X:%02X, RSSI: %d",
                         dev->name, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], dev->rssi);
                Serial.printf("[BLE] Found device %d: %s, RSSI: %d\n",
                              s_scan_result_count + 1, dev->name, dev->rssi);
            }

            s_scan_result_count++;
        }
    }

    void onScanEnd(const NimBLEScanResults &scanResults, int reason) override
    {
        uint32_t elapsed = millis() - s_scan_start_ms;
        ESP_LOGI(TAG, "Scan ended after %lu ms, found %d devices, reason=%d", (unsigned long)elapsed, s_scan_result_count, reason);
        Serial.printf("[BLE] Scan complete after %lu ms! Found %d devices (reason=%d)\n", (unsigned long)elapsed, s_scan_result_count, reason);

        // 输出NimBLE内部扫描结果数量，用于对比
        int internal_count = scanResults.getCount();
        ESP_LOGI(TAG, "NimBLE internal scan results: %d", internal_count);
        Serial.printf("[BLE] NimBLE internal count: %d\n", internal_count);

        /* 按信号强度 RSSI 从高到低排序（数值越大信号越强，-30 > -80）。
         * 使用插入排序：设备数很少（<=20），无需额外内存，稳定且足够快。
         * 必须在 update_state(SCANNING->IDLE) 之前完成，因为 UI 刷新在
         * 该状态切换时触发，确保 UI 拿到的就是已排序的结果。
         */
        for (uint16_t i = 1; i < s_scan_result_count; i++) {
            ble_device_info_t key = s_scan_results[i];
            int16_t j = (int16_t)i - 1;
            while (j >= 0 && s_scan_results[j].rssi < key.rssi) {
                s_scan_results[j + 1] = s_scan_results[j];
                j--;
            }
            s_scan_results[j + 1] = key;
        }

        ESP_LOGI(TAG, "Scan results sorted by RSSI (desc), %d devices", s_scan_result_count);
        Serial.println("[BLE] Devices sorted by RSSI (high -> low):");
        for (uint16_t i = 0; i < s_scan_result_count; i++) {
            Serial.printf("[BLE]   #%u  RSSI=%d  %s\n",
                          (unsigned)(i + 1), s_scan_results[i].rssi, s_scan_results[i].name);
        }

        update_state(BLE_STATE_IDLE, "Scan complete");
    }
};

static MyAdvertisedDeviceCallbacks s_advertised_cb;

static bool connect_to_server(NimBLEAddress address);

static void connect_task(void *arg)
{
    ESP_LOGI(TAG, "Connect task started, waiting for scan to fully stop...");
    Serial.println("[BLE] Connection task starting, ensuring scan is stopped...");
    
    // 等待扫描完全停止（确保不与连接冲突）
    if (s_scan && s_scan->isScanning()) {
        ESP_LOGI(TAG, "Scan still running, stopping...");
        Serial.println("[BLE] Stopping active scan before connect...");
        s_scan->stop();
        delay(500);  // 给予足够时间停止
        s_scan->clearResults();
        ESP_LOGI(TAG, "Scan stopped successfully");
        Serial.println("[BLE] Scan stopped");
    }
    
    // 额外等待，让 BLE 控制器完全就绪
    delay(200);

    /* 连接前重新扫描 3 秒，刷新目标设备地址。
     * 原因：
     * 1) 手机作为外围设备使用随机地址（addr_type=1），RPA 可能已轮换，
     *    原始扫描捕获的 MAC 到连接时已失效 -> BLE_HS_ETIMEOUT(13)。
     * 2) 从原始扫描结束到用户点 Connect 之间手机可能已停止广播。
     * 用最新地址连接；若 3 秒内未再发现该设备，说明手机已不在广播，
     * 直接报错而非空等 3 次 x 15s 超时。
     */
    {
        ESP_LOGI(TAG, "Re-scanning 3s to refresh target address before connect");
        Serial.println("[BLE] Re-scanning 3s to refresh target address...");
        s_scan_result_count = 0;
        memset(s_scan_results, 0, sizeof(s_scan_results));
        s_scan->start(3000, false, true);

        uint32_t t0 = millis();
        while (s_scan && s_scan->isScanning() && millis() - t0 < 4000) {
            delay(50);
        }
        delay(150);  // 等 onScanEnd 回调处理完

        bool found = false;
        for (uint16_t i = 0; i < s_scan_result_count; i++) {
            if (strcmp(s_scan_results[i].name, s_connect_device.name) == 0) {
                ESP_LOGI(TAG, "Refreshed address for %s (addr_type %d->%d)",
                         s_connect_device.name, s_connect_device.addr_type, s_scan_results[i].addr_type);
                Serial.printf("[BLE] Refreshed: %s, addr_type=%d, RSSI=%d\n",
                              s_connect_device.name, s_scan_results[i].addr_type, s_scan_results[i].rssi);
                memcpy(s_connect_device.mac, s_scan_results[i].mac, 6);
                s_connect_device.addr_type = s_scan_results[i].addr_type;
                s_connect_device.rssi = s_scan_results[i].rssi;
                found = true;
                break;
            }
        }
        if (!found) {
            ESP_LOGE(TAG, "'%s' not found in 3s re-scan; phone may have stopped advertising",
                     s_connect_device.name);
            Serial.println("[BLE] ERROR: Device not seen again in 3s re-scan.");
            Serial.println("[BLE] Check: peripheral app in foreground & advertising? screen on?");
            update_state(BLE_STATE_DISCONNECTED, "Device not found (advertising stopped?)");
            s_connect_task_handle = NULL;
            vTaskDelete(NULL);
            return;
        }
    }

    NimBLEAddress address(s_connect_device.mac, s_connect_device.addr_type);
    update_state(BLE_STATE_CONNECTING, "Connecting...");

    bool ok = connect_to_server(address);
    if (!ok) {
        ESP_LOGE(TAG, "Connection failed, cleaning up...");
        Serial.println("[BLE] Connection failed!");
        // 确保清理
        if (s_client) {
            s_client->disconnect();
            NimBLEDevice::deleteClient(s_client);
            s_client = nullptr;
        }
        update_state(BLE_STATE_DISCONNECTED, "Connection failed");
    }

    s_connect_task_handle = NULL;
    ESP_LOGI(TAG, "Connect task finished");
    vTaskDelete(NULL);
}

static bool connect_to_server(NimBLEAddress address)
{
    ESP_LOGI(TAG, "Connecting to %s (type=%d)...", address.toString().c_str(), address.getType());
    Serial.printf("[BLE] connect_to_server: %s, type=%d\n", address.toString().c_str(), address.getType());

    // 关键：在连接前确保扫描完全停止并等待控制器空闲
    if (s_scan) {
        ESP_LOGI(TAG, "Stopping scan before connect...");
        s_scan->stop();
        // 等待足够时间让 BLE 控制器完全清理
        delay(300);
        s_scan->clearResults();
        ESP_LOGI(TAG, "Scan stopped, proceeding with connection");
        Serial.println("[BLE] Scan stopped, ready to connect");
    }

    // 如果有旧 client，先删除
    if (s_client) {
        ESP_LOGI(TAG, "Deleting old client");
        Serial.println("[BLE] Cleaning up old client...");
        s_client->disconnect();
        delay(200);
        NimBLEDevice::deleteClient(s_client);
        s_client = nullptr;
        s_rx_char = nullptr;
        s_tx_char = nullptr;
        ESP_LOGI(TAG, "Old client deleted");
        Serial.println("[BLE] Old client deleted");
        delay(300);
    }

    // 在创建新 client 前，确保 BLE 控制器状态干净
    ESP_LOGI(TAG, "Controller status before connect: %d", esp_bt_controller_get_status());

    ESP_LOGI(TAG, "Creating new client...");
    Serial.println("[BLE] Creating new client...");
    s_client = NimBLEDevice::createClient();
    if (!s_client) {
        ESP_LOGE(TAG, "Failed to create BLE client");
        Serial.println("[BLE] ERROR: createClient failed!");
        return false;
    }
    ESP_LOGI(TAG, "Client created successfully");
    Serial.println("[BLE] Client created");

    // 设置连接参数：更合理的连接间隔和超时
    // 注意：setConnectTimeout 参数单位为毫秒（默认 30000ms = 30秒）
    s_client->setConnectTimeout(5000);  // 5 秒连接超时（单位：毫秒）
    s_client->setConnectionParams(16, 32, 0, 400);  // interval: 16-32ms, latency: 0, timeout: 4000ms

    Serial.println("[BLE] Attempting connection...");
    ESP_LOGI(TAG, "Connecting to %s...", address.toString().c_str());

    // 在连接前添加额外的调试信息
    ESP_LOGI(TAG, "Client state before connect: %d", s_client->getState());
    ESP_LOGI(TAG, "Address type: %d", address.getType());

    bool connected = false;

    // 尝试连接3次
    for (int attempt = 1; attempt <= 3; attempt++) {
        ESP_LOGI(TAG, "Connection attempt %d/3 starting...", attempt);
        Serial.printf("[BLE] Connection attempt %d/3 to %s (type=%d)...\n", 
                      attempt, address.toString().c_str(), address.getType());
        
        // 检查 client 状态
        ESP_LOGI(TAG, "Client state: %d", s_client->getState());

        if (s_client->connect(address)) {
            connected = true;
            ESP_LOGI(TAG, "Connected successfully on attempt %d", attempt);
            Serial.printf("[BLE] Connected on attempt %d!\n", attempt);
            break;
        }

        int error = s_client->getLastError();
        ESP_LOGW(TAG, "Connection attempt %d FAILED with error code: %d", attempt, error);
        Serial.printf("[BLE] Attempt %d failed! Error code: %d\n", attempt, error);

        // NimBLE BLE_HS_E* 错误码参考（来自 ble_hs.h）：
        // 0  = 成功; 2 = BLE_HS_EALREADY(已在连接); 3 = BLE_HS_EINVAL(参数无效)
        // 6  = BLE_HS_ENOMEM; 7 = BLE_HS_ENOTSYNCED(主机未同步)
        // 12 = BLE_HS_ECONTROLLER(控制器错误); 13 = BLE_HS_ETIMEOUT(操作超时)
        // 14 = BLE_HS_EDONE; 15 = BLE_HS_EBUSY(资源忙碌)
        // 30 = BLE_HS_EDISABLED; 29 = BLE_HS_EPREEMPTED
        switch (error) {
            case 13:  // BLE_HS_ETIMEOUT
                Serial.println("[BLE] Timeout: device may be out of range or not advertising.");
                break;
            case 15:  // BLE_HS_EBUSY
                Serial.println("[BLE] Controller busy, scan may still be running.");
                break;
            case 3:   // BLE_HS_EINVAL
                Serial.println("[BLE] Invalid parameters (address/type).");
                break;
            case 12:  // BLE_HS_ECONTROLLER
                Serial.println("[BLE] Controller error.");
                break;
            default:
                Serial.printf("[BLE] Other error: %d\n", error);
                break;
        }

        if (attempt < 3) {
            Serial.println("[BLE] Retrying in 2 seconds...");
            s_client->disconnect();
            delay(2000);
        }
    }

    if (!connected) {
        ESP_LOGE(TAG, "All connection attempts failed");
        Serial.println("[BLE] ERROR: All connection attempts failed!");
        NimBLEDevice::deleteClient(s_client);
        s_client = nullptr;
        return false;
    }

    ESP_LOGI(TAG, "Connected. Discovering services...");
    Serial.println("[BLE] Connected! Discovering services...");
    s_is_connected = true;
    update_state(BLE_STATE_CONNECTED, "Connected, discovering...");

    const auto &services = s_client->getServices();

    ESP_LOGI(TAG, "Found %d services", (int)services.size());
    Serial.printf("[BLE] Found %d services\n", (int)services.size());

    for (auto *svc : services) {
        ESP_LOGI(TAG, "Service: %s", svc->getUUID().toString().c_str());
        Serial.printf("[BLE]   Service: %s\n", svc->getUUID().toString().c_str());
        const auto &chars = svc->getCharacteristics();

        for (auto *ch : chars) {
            NimBLEUUID uuid = ch->getUUID();
            ESP_LOGI(TAG, "  Char: %s", uuid.toString().c_str());
            Serial.printf("[BLE]     Char: %s\n", uuid.toString().c_str());

            if (ch->canNotify() || ch->canIndicate()) {
                if (!s_rx_char) {
                    s_rx_char = ch;
                }
                ESP_LOGI(TAG, "    -> Notify characteristic found");
                Serial.println("[BLE]       -> Notify char found");
            }
            if (ch->canWrite() || ch->canWriteNoResponse()) {
                if (!s_tx_char) {
                    s_tx_char = ch;
                }
                ESP_LOGI(TAG, "    -> Write characteristic found");
                Serial.println("[BLE]       -> Write char found");
            }
        }
    }

    if (s_rx_char) {
        if (s_rx_char->subscribe(s_rx_char->canNotify(), notify_callback)) {
            ESP_LOGI(TAG, "Subscribed for notifications");
            Serial.println("[BLE] Subscribed for notifications");
        } else {
            ESP_LOGW(TAG, "Failed to subscribe for notifications");
            Serial.println("[BLE] WARN: Failed to subscribe");
        }
    } else {
        Serial.println("[BLE] WARN: No notify characteristic found");
    }

    if (!s_tx_char) {
        Serial.println("[BLE] WARN: No write characteristic found");
    }

    const uint8_t *addr_native = address.getVal();
    memcpy(s_remote_mac, addr_native, 6);

    update_state(BLE_STATE_CONNECTED, "Connected");
    Serial.println("[BLE] Connection successful!");
    return true;
}

extern "C" {

void ble_manager_init(void)
{
    ESP_LOGI(TAG, "Initializing BLE (NimBLE)...");
    Serial.println("[BLE] Initializing NimBLE...");

    // 关闭 WiFi，避免与 BLE 共享 2.4GHz 射频前端造成干扰
    WiFi.mode(WIFI_OFF);
    esp_wifi_stop();
    Serial.println("[BLE] WiFi disabled to avoid BLE interference");
    ESP_LOGI(TAG, "WiFi disabled to avoid RF interference with BLE");
    delay(100);

    // 输出内存信息
    uint32_t free_heap = ESP.getFreeHeap();
    uint32_t free_psram = ESP.getFreePsram();
    uint32_t min_free_heap = ESP.getMinFreeHeap();
    Serial.printf("[BLE] Free heap: %lu, Min free heap: %lu, PSRAM: %lu\n", 
                  (unsigned long)free_heap, (unsigned long)min_free_heap, (unsigned long)free_psram);
    ESP_LOGI(TAG, "Free heap: %lu, Min: %lu, PSRAM: %lu",
             (unsigned long)free_heap, (unsigned long)min_free_heap, (unsigned long)free_psram);

    // 检查堆内存是否足够（BLE 控制器至少需要 ~30KB 连续内存）
    if (free_heap < 40000) {
        ESP_LOGE(TAG, "Low memory! Only %lu bytes free. BLE may fail.", (unsigned long)free_heap);
        Serial.println("[BLE] WARNING: Low memory, BLE scan may not work!");
    }

    NimBLEDevice::init("ESP32-S3-Display");
    NimBLEDevice::setPower(ESP_PWR_LVL_P9);
    NimBLEDevice::setMTU(256);

    // 给 NimBLE 初始化一点时间
    delay(500);

    // 检查 BLE 控制器状态
    esp_bt_controller_status_t bt_status = esp_bt_controller_get_status();
    ESP_LOGI(TAG, "BLE controller status: %d (0=IDLE, 1=INITED, 2=ENABLED)", bt_status);
    Serial.printf("[BLE] BT controller status: %d\n", bt_status);
    if (bt_status != ESP_BT_CONTROLLER_STATUS_ENABLED) {
        ESP_LOGE(TAG, "BLE controller NOT enabled! Scan will fail.");
        Serial.println("[BLE] ERROR: BT controller not enabled!");
        // 尝试手动启用
        Serial.println("[BLE] Attempting to enable BT controller...");
        esp_bt_controller_enable(ESP_BT_MODE_BLE);
        delay(200);
        bt_status = esp_bt_controller_get_status();
        Serial.printf("[BLE] BT status after enable: %d\n", bt_status);
    }

    free_heap = ESP.getFreeHeap();
    Serial.printf("[BLE] Free heap after init: %lu bytes\n", (unsigned long)free_heap);

    s_scan = NimBLEDevice::getScan();
    if (!s_scan) {
        ESP_LOGE(TAG, "Failed to get NimBLEScan instance!");
        Serial.println("[BLE] ERROR: getScan() returned null!");
        return;
    }

    s_scan->setScanCallbacks(&s_advertised_cb, false);
    s_scan->setActiveScan(true);
    // NimBLE setInterval/setWindow 参数单位为毫秒
    // interval=48ms, window=48ms = 100% 占空比，快速切换信道
    s_scan->setInterval(48);
    s_scan->setWindow(48);
    s_scan->setDuplicateFilter(false);
    s_scan->setLimitedOnly(false);  // 不限制为有限可发现模式

    s_data_queue = xQueueCreate(20, sizeof(ble_data_msg_t));
    if (!s_data_queue) {
        ESP_LOGE(TAG, "Failed to create data queue");
    }

    ESP_LOGI(TAG, "BLE initialized successfully (s_scan=%p)", s_scan);
    Serial.printf("[BLE] NimBLE initialized, scan=%p, heap=%lu\n", s_scan, (unsigned long)free_heap);
    update_state(BLE_STATE_IDLE, "BLE Ready");
}

void ble_manager_start_scan(void)
{
    if (!s_scan) {
        ESP_LOGE(TAG, "s_scan is NULL, cannot start scan");
        Serial.println("[BLE] ERROR: s_scan is null!");
        return;
    }

    if (s_state == BLE_STATE_SCANNING) {
        ESP_LOGW(TAG, "Already scanning");
        return;
    }

    // 停止并清理之前可能残留的扫描状态
    s_scan->stop();
    delay(50);  // 给控制器时间完成停止操作
    s_scan->clearResults();

    s_scan_result_count = 0;
    memset(s_scan_results, 0, sizeof(s_scan_results));

    update_state(BLE_STATE_SCANNING, "Scanning...");

    Serial.println("[BLE] Starting BLE scan (10 seconds)...");
    ESP_LOGI(TAG, "Starting BLE scan for 10 seconds...");

    // NimBLE start() 的 duration 参数单位为毫秒，10s = 10000ms
    // restart=true 确保即使上次扫描状态残留也能正确重启
    bool ok = s_scan->start(10000, false, true);
    if (!ok) {
        ESP_LOGE(TAG, "Scan failed to start");
        Serial.println("[BLE] ERROR: Scan failed to start!");
        update_state(BLE_STATE_IDLE, "Scan failed");
        return;
    }

    ESP_LOGI(TAG, "Scan started (10000ms)");
    s_scan_start_ms = millis();
    Serial.printf("[BLE] Scan started at %lu ms, waiting for results...\n", (unsigned long)s_scan_start_ms);
}

void ble_manager_stop_scan(void)
{
    if (s_scan) {
        s_scan->stop();
    }
    update_state(BLE_STATE_IDLE, "Scan stopped");
}

void ble_manager_connect(const ble_device_info_t *device)
{
    if (s_is_connected || !device) {
        ESP_LOGW(TAG, "Already connected or null device");
        return;
    }

    if (s_connect_task_handle) {
        ESP_LOGW(TAG, "Connection already in progress");
        return;
    }

    memcpy(&s_connect_device, device, sizeof(ble_device_info_t));

    Serial.printf("[BLE] Connecting to: %s [%02X:%02X:%02X:%02X:%02X:%02X] type=%d\n",
                  device->name,
                  device->mac[0], device->mac[1], device->mac[2],
                  device->mac[3], device->mac[4], device->mac[5],
                  device->addr_type);
    ESP_LOGI(TAG, "Connecting to: %s, addr_type=%d",
             device->name, device->addr_type);

    // 增加栈大小到 16384 字节，确保 NimBLE GATT 操作有足够空间
    BaseType_t ret = xTaskCreate(connect_task, "BLE_CONN", 16384, NULL, 5, &s_connect_task_handle);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create connect task (stack size issue)");
        Serial.println("[BLE] ERROR: Failed to create connection task! Try reducing stack size.");
        update_state(BLE_STATE_DISCONNECTED, "Connect task failed");
    }
}

void ble_manager_disconnect(void)
{
    if (s_client && s_is_connected) {
        s_client->disconnect();
    }
    s_is_connected = false;
    s_rx_char = nullptr;
    s_tx_char = nullptr;
    /* 清空帧重组缓冲区，避免下次连接时残留半帧污染首帧 */
    s_frame_len = 0;
    s_frame_buf[0] = '\0';
    /* 清空数据队列，避免断开时还在处理旧数据 */
    if (s_data_queue) {
        ble_data_msg_t msg;
        while (xQueueReceive(s_data_queue, &msg, 0) == pdPASS) {}
    }
    update_state(BLE_STATE_DISCONNECTED, "Disconnected");
}

void ble_manager_send_data(uint8_t *data, uint16_t len)
{
    if (!s_is_connected || !s_tx_char) {
        ESP_LOGW(TAG, "Cannot send: not connected or no TX char");
        return;
    }

    uint16_t offset = 0;
    while (offset < len) {
        uint16_t chunk = (len - offset > 20) ? 20 : (len - offset);
        s_tx_char->writeValue(data + offset, chunk, false);
        offset += chunk;
    }
}

ble_state_t ble_manager_get_state(void)
{
    return s_state;
}

void ble_manager_get_scan_results(ble_device_info_t *results, uint16_t *count)
{
    uint16_t c = (s_scan_result_count < BLE_SCAN_RESULT_MAX) ? s_scan_result_count : BLE_SCAN_RESULT_MAX;
    if (results) {
        for (uint16_t i = 0; i < c; i++) {
            memcpy(&results[i], &s_scan_results[i], sizeof(ble_device_info_t));
        }
    }
    *count = c;
}

void ble_manager_set_data_callback(ble_data_callback_t cb)
{
    s_data_cb = cb;
}

void ble_manager_set_state_callback(ble_state_callback_t cb)
{
    s_state_cb = cb;
}

void ble_manager_process_data(void)
{
    if (!s_data_queue || !s_data_cb) return;

    ble_data_msg_t msg;
    while (xQueueReceive(s_data_queue, &msg, 0) == pdPASS) {
        /* 将本次 notify 收到的字节喂入帧重组缓冲区，
         * 遇到帧尾 ';' 即输出一帧完整数据。 */
        for (uint16_t i = 0; i < msg.len; i++) {
            char c = (char)msg.data[i];
            /* 忽略换行符：部分 BLE 串口模块在 ';' 后会追加 \r\n，
             * 丢弃它们可保持帧干净，避免原始帧显示出现空行。 */
            if (c == '\r' || c == '\n') continue;

            if (s_frame_len < sizeof(s_frame_buf) - 1) {
                s_frame_buf[s_frame_len++] = c;
            } else {
                /* 缓冲区满仍未见 ';'，丢弃半帧重新同步 */
                ESP_LOGW(TAG, "Frame buffer overflow, resync");
                s_frame_len = 0;
                s_frame_buf[s_frame_len++] = c;
            }

            if (c == ';') {
                /* 一帧完整，交给上层解析（含帧尾 ';'） */
                s_frame_buf[s_frame_len] = '\0';
                s_data_cb((uint8_t *)s_frame_buf, s_frame_len);
                s_frame_len = 0;
            }
        }
    }
}

/* 解析 "v1,v2,...,v11;" 格式帧。容错：跳过非数字前导字符，
 * 按逗号/分号分隔提取数值，支持前导零（如 "0920"→920）。 */
uint8_t ble_manager_parse_frame(const uint8_t *data, uint16_t len,
                                int16_t *values, uint8_t max_count)
{
    if (!data || !values || max_count == 0) return 0;

    uint8_t count = 0;
    uint16_t i = 0;
    while (i < len && count < max_count) {
        /* 跳到下一个数字起点（支持负号） */
        while (i < len) {
            char c = (char)data[i];
            if ((c >= '0' && c <= '9') || c == '-') break;
            i++;
        }
        if (i >= len) break;

        int32_t v = 0;
        int16_t sign = 1;
        if ((char)data[i] == '-') { sign = -1; i++; }

        bool any = false;
        while (i < len && (char)data[i] >= '0' && (char)data[i] <= '9') {
            v = v * 10 + ((char)data[i] - '0');
            i++;
            any = true;
        }
        if (any) {
            values[count++] = (int16_t)(v * sign);
        }

        /* 跳到下一个分隔符（逗号/分号）之后 */
        while (i < len && (char)data[i] != ',' && (char)data[i] != ';') i++;
        if (i < len) i++;  /* 跳过分隔符 */
    }
    return count;
}

}
